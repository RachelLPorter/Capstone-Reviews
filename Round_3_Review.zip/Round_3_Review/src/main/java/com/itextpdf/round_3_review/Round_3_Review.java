/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.itextpdf.round_3_review;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.List;
import com.itextpdf.layout.element.ListItem;



public class Round_3_Review {
   
    
    public static void main(String[] args) throws IOException {
        //name and location of the .csv file to be read in 
        //final String CSVFILENAME = "C:\\Users\\mezin\\Box\\2019 Spring Capstone\\Round 1\\Round_1_Feb_10_2019.csv";
        final String CSVFILENAME = "C:\\Users\\mezin\\Box\\2019 Spring Capstone\\Testing\\test-1-16-2019.csv";
        
        //create the array of students called roster, calls method that creates the student objects from passing in the CSV file
        ArrayList<Student> roster = createStudents(CSVFILENAME);
        //calls create feedback array, sends the csv file location and the roster populated with student objects
        createFeedback(CSVFILENAME, roster);
        //creates the teams from calling the team array...not really used yet in this version of code
        ArrayList<Team> teamList = createTeams(roster, CSVFILENAME);
        //final step to create the documents that are saved in the shared folder
        CreateDocs(CSVFILENAME, roster, teamList);
    }
    
    public static ArrayList<Student> createStudents (String csvFileName){
        //create the roster ArrayList to store the Student objects
        ArrayList <Student> roster = new ArrayList <Student>();
            
        //contain in try-catch statement 
        try {
            //create file object
            File file = new File(csvFileName);
            
            //Scanner objects to read the file twice
            Scanner createObjects = new Scanner (file); //create the objects
            
            //read first line into string -- not needed
            String nextLine = createObjects.nextLine();
            //read second line into a string -- use to create variables to determine column name
            nextLine = createObjects.nextLine();
            //split string into an array by the delimiter "#"
            String[] studentLine = nextLine.split("#");
            int numOfCols = studentLine.length;
            
            //create variables to store column numbers of the defining student object titles
            int locationLast = -1, locationFirst = -1, locationEmail = -1, locationTeamName = -1, locationTeamNum = -1;
            
            for (int i = 0; i < numOfCols; i++){
                //saves column location of last name 
                if (studentLine[i].contains("Recipient Last Name")){
                    locationLast = i;
                }
                //saves column location of first name
                else if (studentLine[i].contains("Recipient First Name")){
                    locationFirst = i;
                }
                //saves column location of email
                else if (studentLine[i].contains("Recipient Email")){
                    locationEmail = i;
                }
                //saves column location of team number
                else if (studentLine[i].contains("TEAMNUM")){
                    locationTeamNum = i;
                    // check System.out.println(locationTeamNum);
                }
                //saves column location of team name 
                else if (studentLine[i].contains("TEAMNAME")){
                    locationTeamName = i;
                }
            }
            //read the other line that is a third line that contains additional metadata
            nextLine = createObjects.nextLine();
            
            boolean again = true;
            
            while(again){
                //checks to see if there is another line after current 
                if(createObjects.hasNext()){
                    nextLine = createObjects.nextLine();
                }
                else{
                    
                    break;
                }
                //splits line based on list separator##, makes sure that has the correct number of columns 
                studentLine = nextLine.split("#", numOfCols);
                while(studentLine.length < numOfCols){
                    nextLine = nextLine + createObjects.nextLine();
                    studentLine = nextLine.split("#", numOfCols);
                }
                
                //check System.out.println(count++ + " " );
                //check System.out.println(studentLine.length + " ");
                
                //split the read in line into studentLine
                studentLine = nextLine.split("#",numOfCols);
                
                //create the student object with the personal information and self review
                String lname = studentLine[locationLast];
                //check System.out.println(lname);
                String fname = studentLine[locationFirst];
                //check System.out.println(fname);
                String email = studentLine[locationEmail];
                //check System.out.println(email);
                //String teamNumString = studentLine[locationTeamNum];
                //int teamNum = teamNumString;
                //check System.out.println(locationTeamNum);
                //check System.out.println(studentLine.length);
                //check System.out.println(studentLine[locationTeamNum]);
                int teamNum = Integer.parseInt(studentLine[locationTeamNum]);
                //check System.out.println(teamNum);
                String teamName = studentLine[locationTeamName];
                //check System.out.println(teamName);

                //create the object
                Student s = new Student(fname, lname, email, teamNum, teamName);
                //save the object to the arraylist - student object added to roster
                roster.add(s);  
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Round_3_Review.class.getName()).log(Level.SEVERE, null, ex);
        }
        //returns completed student roster
        return roster;
    } 
    
    public static void createFeedback(String csvFileName, ArrayList<Student> roster){
        File file = new File(csvFileName);
        
        try {
            //Scanner objects to read the file twice
            Scanner createObjects = new Scanner (file); //create the objects
            
            //read first line into string -- not needed
            String nextLine = createObjects.nextLine();
            //read second line into a string -- use to create variables to determine column name
            nextLine = createObjects.nextLine();
            //split string into an array by the delimiter "/"
            String[] feedbackLine = nextLine.split("#");
            int numOfCols = feedbackLine.length;
            
            //create variables to store column numbers of the defining student object titles
            int locationLast = -1, locationFirst = -1, locationDate = -1;
            
            //creates arrays to hold locations of each column containing information relevant to the reviewed information groups 
            int[] reviewedNames = new int[6];
            int[] locationTech = new int[6];
            int[] locationAna = new int[6];
            int[] locationCom = new int[6];
            int[] locationPart = new int[6];
            int[] locationPerf = new int[6];
            int[] locationWell = new int[6];
            int[] locationImpr = new int[6];
            int[] locationAdd = new int[6];
            
            //determine column numbers for each of the below information categories 
            for (int i = 0; i < numOfCols; i++){
                if (feedbackLine[i].contains("Recipient Last Name")){
                    locationLast = i;
                }
                else if (feedbackLine[i].contains("Recipient First Name")){
                    locationFirst = i;
                }
                else if (feedbackLine[i].contains("End Date")){
                    locationDate = i;
                }
                else if (feedbackLine[i].contains("technology") /*&& checkArray(locationTech, i)*/){
//                    for (int j = 0; j < locationTech.length; j++){
//                        if(locationTech[j] == 0){
//                            locationTech[j] = i;
//                        }
//                        break;
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    //this determines what number of the array is being saved to make sure that each column is being saved for each group
                    locationTech[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("analytical")){
//                    for (int j = 0; j < locationAna.length; j++){
//                        if(locationAna[j] == 0){
//                            locationAna[j] = i;
//                        }                     
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    locationAna[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("communication")){
//                    for (int j = 0; j < locationCom.length; j++){
//                        if(locationCom[j] == 0){
//                            locationCom[j] = i;
//                        }
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    locationCom[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("participation")){
//                    for (int j = 0; j < locationPart.length; j++){
//                        if(locationPart[j] == 0){
//                            locationPart[j] = i;
//                        }
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    locationPart[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("performance")){
//                    for (int j = 0; j < locationPerf.length; j++){
//                        if(locationPerf[j] == 0){
//                            locationPerf[j] = i;
//                        }
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    locationPerf[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("strengths")){
//                    for (int j = 0; j < locationWell.length; j++){
//                        if(locationWell[j] == 0){
//                            locationWell[j] = i;
//                        }
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    locationWell[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("growth")){
//                    for (int j = 0; j < locationImpr.length; j++){
//                        if(locationImpr[j] == 0){
//                            locationImpr[j] = i;
//                        }
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    locationImpr[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("Comments")){
//                    for (int j = 0; j < locationAdd.length; j++){
//                        if(locationAdd[j] == 0){
//                            locationAdd[j] = i;
//                        }
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    locationAdd[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }
                else if (feedbackLine[i].contains("teammate") /*&& checkArray(reviewedNames, i, countNames)*/ ){
//                    countNames++;
//                    for (int j = 0; j < reviewedNames.length; j++){
//                        if(reviewedNames[j] == 0){
//                            reviewedNames[j] = i;
//                        }
//                    }
//                    System.out.println(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()));
                    reviewedNames[Integer.parseInt(feedbackLine[i].substring(feedbackLine[i].length()-1,feedbackLine[i].length()))] = i;
                }

            }
            
            
            //read the other line that is a third line that contains additional metadata
            nextLine = createObjects.nextLine();
            
            boolean again = true;

            while(again){
                //make sure has another line
                if(createObjects.hasNext()){
                    nextLine = createObjects.nextLine();
                }
                else{
                    
                    break;
                }
                //split the feedback on the correct # and has correct number of columns 
                feedbackLine = nextLine.split("#", numOfCols);
                while(feedbackLine.length < numOfCols){
                    nextLine = nextLine + createObjects.nextLine();
                    feedbackLine = nextLine.split("#", numOfCols);
                }
                
                //System.out.println(count++ + " " );
                //System.out.println(feedbackLine.length + " ");
                
                //split the read in line into feedbackline
                feedbackLine = nextLine.split("#",numOfCols);
                
                //provider location out here to reduce redundancy 
                String provider = feedbackLine[locationFirst] + " " + feedbackLine[locationLast]; 
                //System.out.println("Provider: " + provider);
                
                for (int i = 0; i < 6; i++){
                    //create variables to contain feedback review data responses, save the responses into variables
                    System.out.println("Provider: " + provider);
                    String receiver;
                    if (i == 0){
                        receiver = provider;
                        System.out.println("Receiver: " + receiver);
                    }
                    else {
                        //System.out.println(feedbackLine.length);
                        receiver = feedbackLine[reviewedNames[i]];
                        System.out.println("Receiver: " + receiver);
                    }
                    //checks -- System.out.println(locationTech.length);
                    //checks -- System.out.println(i);
                    String technical = feedbackLine[locationTech[i]];
                    System.out.println("Technical: " + technical);
                    String analytical = feedbackLine[locationAna[i]];
                    System.out.println("Analytical: " + analytical);
                    String communication = feedbackLine[locationCom[i]];
                    System.out.println("Communication: " + communication);
                    String participation = feedbackLine[locationPart[i]];
                    System.out.println("Participation: " + participation);
                    String performance = feedbackLine[locationPerf[i]];
                    System.out.println("Performance: " + performance);
                    String strength = feedbackLine[locationWell[i]];
                    System.out.println("Strength: " + strength);
                    String improve = feedbackLine[locationImpr[i]];
                    System.out.println("Improvements: " + improve);
                    String additional = feedbackLine[locationAdd[i]];
                    System.out.println("Additional Comments: " + additional);
                    String date = feedbackLine[locationDate];
                    System.out.println("Date Submitted: " + date);
                    
                    System.out.println(); //blank line;
                    
                    //creates temp student object to be used 
                    Student sProvider = new Student();
                    for(Student s: roster){
                        if(s.getName().equalsIgnoreCase(provider)){
                            sProvider = s;
                        }
                    }
                    Student sReceiver = new Student();
                    for(Student s: roster){
                        if(s.getName().equalsIgnoreCase(receiver)){
                            sReceiver = s;
                        }
                    }
                    
                    Feedback f = new Feedback (sProvider, sReceiver, technical, analytical, communication, participation, performance, strength, improve, additional, date);
                    
                    sProvider.addToProvidedReviews(f);
                    sReceiver.addToReview(f);
                }
            }
          
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Round_3_Review.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //not really used 
    public static boolean checkArray (int[] array, int i, int count){
        boolean result = false;
        for (int x = 0; x < array.length; x++){
            if(array[count] != i){
                result = true;
            }
        }
        return result;
    }
    //not really used 
    public static boolean checkArray (int[] array, int i){
        boolean result = false;
        for (int x = 0; x < array.length; x++){
            if (array[x] == i){
                result = false;
            }
            else if (array[x] != i && array[x] == 0){
                result = true;
                System.out.println("The else if that would result in a true ran.");
            }
            else{
                result = false;
                System.out.println("Error within the method checkArray.");
            }
        }
        return result;
    }
    
    //not really used yet 
    public static ArrayList<Team> createTeams (ArrayList<Student> roster, String csvFileName){
        //create the teams ArrayList to store the team objects
        ArrayList <Team> teamList = new ArrayList <Team>();
            
        try {
            File file = new File(csvFileName);
            
            //Scanner objects to read the file twice
            Scanner createObjects = new Scanner (file); //create the objects
            
            //read first line into string -- not needed
            String nextLine = createObjects.nextLine();
            //read second line into a string -- use to create variables to determine column name
            nextLine = createObjects.nextLine();
            //split string into an array by the delimiter "/"
            String[] teamLine = nextLine.split("#");
            
            int numOfCols = teamLine.length;
            
            //create variables to store column numbers of the defining student object titles
            int locationFaculty = -1, locationMeetPlace = -1, locationTeamName = -1, locationTeamNum = -1;
            
            for (int i = 0; i < teamLine.length; i++){
                if (teamLine[i].contains("faculty sponsor")){
                    locationFaculty = i;
                }
                else if (teamLine[i].contains("meeting place")){
                    locationMeetPlace = i;
                }
                else if (teamLine[i].contains("TEAMNUM")){
                    locationTeamNum = i;
                }
                else if (teamLine[i].contains("TEAMNAME")){
                    locationTeamName = i;
                }
            }
            //read the other line that is a third line that contains additional metadata
            nextLine = createObjects.nextLine();
            
            //copy over
            
            boolean again = true;
            
            int count = 0;
            
            while(again){
                
                if(createObjects.hasNext()){
                    nextLine = createObjects.nextLine();
                }
                else{
                    
                    break;
                }
                
                teamLine = nextLine.split("#", numOfCols);
                while(teamLine.length < numOfCols){
                    nextLine = nextLine + createObjects.nextLine();
                    teamLine = nextLine.split("#", numOfCols);
                }
                
                //check System.out.println(count++ + " " );
                //check System.out.println(teamLine.length + " ");
                
                //split the read in line into studentLine
                teamLine = nextLine.split("#",numOfCols);
            
                
                //create the student object with the personal information and self review
                String faculty = teamLine[locationFaculty];
                String meetPlace = teamLine[locationMeetPlace];
                int teamNum = Integer.parseInt(teamLine[locationTeamNum]);
                String teamName = teamLine[locationTeamName];

                boolean alreadyCreated = false;
                for(Team t: teamList){
                    if(t.getTeamNum() == teamNum){
                        alreadyCreated = true;
                    }
                }
                
                if(alreadyCreated != true){
                    //create the object
                    Team t = new Team(faculty, meetPlace, teamNum, teamName);
                    //save the object to the arraylist
                    teamList.add(t); 
                }
                 
            }    
                
            //now add students to the teams
            for(Student s: roster){
                for(Team t: teamList){
                    if(s.getTeamNum() == t.getTeamNum()){
                        t.addTeam(s);
                    }
                }
            } 
                
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Round_3_Review.class.getName()).log(Level.SEVERE, null, ex);
        }
       return teamList; 
    }
    
    //creates the actual documents being used and shared 
    public static void CreateDocs (String csvfilename, ArrayList<Student> roster, ArrayList<Team> teamList)throws IOException {
        
        
        for (Student s: roster){            
            
            //String dest = "C:\\Users\\mezin\\Box\\2019 Spring Capstone\\Round 1\\" + s.getLname() + s.getFname() + ".pdf";
            String dest = "C:\\Users\\mezin\\Box\\2019 Spring Capstone\\Testing\\" + s.getLname() + s.getFname() + ".pdf";
            
            //saved in two parts: the average and the personal review 
            double tech[] = s.TechAvg();
            double ana[] = s.AnaAvg();
            double com[] = s.ComAvg();
            double part[] = s.PartAvg();
            double perf[] = s.PerfAvg();
            
            
            
            
            
            //initialize pdf writer
            FileOutputStream fos = new FileOutputStream(dest);
            PdfWriter writer = new PdfWriter(fos);

            //initialize pdf document
            PdfDocument pdf = new PdfDocument(writer);

            //initialize document
            Document document = new Document (pdf);
            
            //gives identifying information
            document.add(new Paragraph(s.getName() + "\n" + s.getEmail() + "\n" + s.getTeamName() + "\nSpring 2019 Round 1 Capstone 360 Review"));
            
            //start actual review info
            document.add(new Paragraph ("\nSkills Review"));
            
            //create a list 
            List listAverage = new List()
                    .setSymbolIndent(12)
                    .setListSymbol("\u2022");
           
            listAverage.add(new ListItem("Technical Average: " + tech[1] + "\t\t\tPersonal Review: " + tech[0]));
            listAverage.add(new ListItem("Analytical Average: " + ana[1] + "\t\t\tPersonal Review: " + ana[0]));
            listAverage.add(new ListItem("Communication Average: " + com[1] + "\t\tPersonal Review: " + com[0]));
            listAverage.add(new ListItem("Participation Average: " + part[1] + "\t\t\tPersonal Review: " + part[0]));
            listAverage.add(new ListItem("Performance Average: " + perf[1] + "\t\t\tPersonal Review: " + perf[0]));
            document.add(listAverage);
            
            document.add(new Paragraph("\nExcellent = 5 | Very Good = 4 | Satisfactory = 3 | Fair = 2 | Poor = 1"));
            
            document.add(new Paragraph ("\nStrengths:\n"));
            document.add(s.AllStrength());
            /*List listStrength = new List()
                    .setSymbolIndent(12)
                    .setListSymbol("\u2022");
            listStrength.add(new ListItem(s.AllStrength()));
            document.add(listStrength);*/
            
            document.add(new Paragraph ("\nImprovements:\n"));
            document.add(s.AllImprove());           
            /*List listImprove = new List()
                    .setSymbolIndent(12)
                    .setListSymbol("\u2022");
            listImprove.add(s.AllImprove());
            document.add(listImprove);*/
            
            document.add(new Paragraph ("\nAdditional Comments:\n"));
            document.add(s.AllAdditional());           
            /*List listAdditional = new List()
                    .setSymbolIndent(12)
                    .setListSymbol("\u2022");            
            listAdditional.add(s.AllAdditional());
            document.add(listAdditional);*/

            //close doc
            document.close();
            
            
            //File file = new File(dest);
            //file.getParentFile().mkdirs();
            
            /*
            System.out.println(s.getName());
            System.out.println(s.getTeamName());
            System.out.println(s.TechAvg());
            System.out.println(s.AnaAvg());
            System.out.println(s.ComAvg());
            System.out.println(s.PartAvg());
            System.out.println(s.PerfAvg());
            System.out.println(s.AllStrength());
            System.out.println(s.AllImprove());
            System.out.println(s.AllAdditional());*/
        }
        
    }
}